from stackoverflow_users_taginfo import tag_cloud

tag_cloud(link=22656)
