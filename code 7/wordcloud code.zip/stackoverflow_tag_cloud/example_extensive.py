from stackoverflow_users_taginfo import tag_cloud

tag_cloud(link=22656, lim_num_tags=1000, image_dims=(3840, 2160),
          out_filepath="example_extensive_output.png")
