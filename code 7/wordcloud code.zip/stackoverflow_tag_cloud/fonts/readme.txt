Please note that the fonts were obtained from :

http://www.dafont.com/chinacat.font
http://www.dafont.com/sketch-serif.font
http://www.dafont.com/short-stack.font