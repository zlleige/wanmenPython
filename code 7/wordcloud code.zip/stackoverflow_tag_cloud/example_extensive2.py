from stackoverflow_users_taginfo import tag_cloud

tag_cloud(link="http://meta.stackexchange.com/users/22656",
          image_dims=(1920, 1200),
          out_filepath="example_extensive2_output.png")
